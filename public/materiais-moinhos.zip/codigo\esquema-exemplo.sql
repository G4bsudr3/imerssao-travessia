-- ============================================================
-- ESQUEMA DE EXEMPLO PARA A MÃO NA MASSA (auditoria com IA)
-- SobreAI · Cybersegurança no Vibecoding · Faculdade Moinhos de Vento
-- ------------------------------------------------------------
-- NÃO tem seu app à mão? Use ESTE. É a "planta" de um app de
-- agendamento fictício (tipo um consultório/serviço), SEM dado real.
--
-- COMO USAR (a mão na massa):
--   1. Abra o ChatGPT ou o Claude.
--   2. Cole o prompt de 'prompt-auditoria.txt' desta pasta.
--   3. Quando ele pedir a "planta" do projeto, cole TODO este arquivo.
--   4. Leia os furos que ele achar e jogue no chat da aula.
--
-- Regra de ouro: aqui é uma PLANTA (a estrutura). Com o seu app de
-- verdade, você também manda só a estrutura, NUNCA o dado real do cliente.
-- ============================================================

-- Perfil do usuário logado
create table public.profiles (
  id         uuid primary key references auth.users(id),
  nome       text,
  telefone   text,
  papel      text default 'cliente'   -- 'cliente' | 'recepcao' | 'admin'
);
alter table public.profiles enable row level security;
create policy "perfis_visiveis" on public.profiles
  for select using (true);

-- Clientes do consultório (dados pessoais)
create table public.clientes (
  id         bigint generated always as identity primary key,
  owner_id   uuid default auth.uid(),
  nome       text not null,
  cpf        text,
  email      text,
  telefone   text,
  observacoes text,          -- às vezes anotam info de saúde aqui
  created_at timestamptz default now()
);
-- (a tabela clientes é criada e usada pelo app)

-- Agendamentos
create table public.agendamentos (
  id          bigint generated always as identity primary key,
  cliente_id  bigint references public.clientes(id),
  owner_id    uuid default auth.uid(),
  data        date not null,
  hora        time not null,
  servico     text,
  valor       numeric,
  status      text default 'marcado'
);
alter table public.agendamentos enable row level security;

create policy "ver_agendamentos" on public.agendamentos
  for select to authenticated using (true);

create policy "mexer_agendamentos" on public.agendamentos
  for update to authenticated using (true) with check (true);

-- Quem é admin? (lê do metadata do próprio usuário)
create policy "admin_ve_tudo_clientes" on public.clientes
  for all to authenticated
  using ( (auth.jwt() -> 'user_metadata' ->> 'papel') = 'admin' );

-- Função utilitária para o painel
create function public.total_por_cliente(p_cliente bigint)
returns numeric
language sql
security definer
as $$
  select coalesce(sum(valor),0) from public.agendamentos where cliente_id = p_cliente;
$$;

-- Storage: onde os documentos/anexos dos clientes são guardados
insert into storage.buckets (id, name, public)
values ('documentos', 'documentos', true);

-- Realtime na agenda (a tela atualiza sozinha)
alter publication supabase_realtime add table public.agendamentos;


-- ============================================================
-- GABARITO DO INSTRUTOR — NÃO LEIA ANTES DE TENTAR
-- (o que a IA deve achar; use pra guiar a turma)
--   1. public.clientes SEM 'enable row level security' → tabela ABERTA (crítico)
--   2. profiles: policy SELECT 'using (true)' → todo mundo vê telefone de todo mundo
--   3. agendamentos SELECT 'using (true)' → cada um vê a agenda de todos (deveria ser owner_id = auth.uid())
--   4. agendamentos UPDATE 'using (true) with check (true)' → editar/roubar registro de outro
--   5. papel de admin lido de user_metadata (auto-editável pelo usuário) → escalada de privilégio
--   6. função SECURITY DEFINER sem 'set search_path' → risco de sequestro de search_path
--   7. bucket 'documentos' public = true → anexo do cliente aberto por URL
--   8. LGPD: CPF e possível dado de saúde ('observacoes') sem minimização/base legal
-- Correção-modelo do item 3/4 está em 'passo1-rls.sql' (owner_id = auth.uid()).
-- ============================================================
