-- Setup do post-generator no Supabase.
-- Tabela de posts + RLS (sem policy pública => só a edge function, via service_role, acessa)
-- + bucket de imagens PRIVADO.

create table if not exists public.posts (
  id          bigint generated always as identity primary key,
  caption     text not null,
  image_prompt text,
  image_path  text,
  status      text not null default 'pendente',  -- pendente | aprovado | descartado
  created_at  timestamptz not null default now()
);

alter table public.posts enable row level security;
-- Nenhuma policy: anon/usuário comum não acessa. A edge function usa service_role (bypassa RLS).

-- Bucket privado pra guardar as imagens geradas (download via URL assinada).
insert into storage.buckets (id, name, public)
values ('posts', 'posts', false)
on conflict (id) do nothing;
