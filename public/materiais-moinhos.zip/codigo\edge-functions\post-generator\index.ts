// post-generator — Edge Function (Deno) do Supabase · VERSÃO SEGURA (atrás do Cloudflare Worker).
// Renderiza HTML (servido como text/html pelo Worker). Exige um HEADER SECRETO (x-proxy-secret)
// que só o Worker envia — acesso direto = 403. Fallback ?key= pra teste.
//
// A IA analisa IMAGENS DE REFERÊNCIA (visão), escolhe um TIPO aleatório e sobrepõe a LOGO.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ╔══════════════════════════════════════════════════════════════╗
// ║  CONFIG — edite com a SUA identidade                          ║
// ╚══════════════════════════════════════════════════════════════╝
const BRAND = {
  name: "Sua Marca",
  niche: "vibe coding, IA e segurança para builders",
  tone: "didático, direto e descontraído, em pt-BR",
  audience: "devs e founders que constroem com IA",
  colors: { bg: "#0e1726", accent: "#9fe870", text: "#ffffff" },
  // Logo sobreposta em TODO post. Use PNG (de preferência transparente).
  logoUrl: "https://dummyimage.com/360x140/9fe870/0e1726.png&text=SUA+LOGO",
  // Imagens de REFERÊNCIA do seu estilo (a IA analisa por visão). Troque pelas suas.
  referenceImages: [
    "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=768",
    "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=768",
  ],
};

const TYPES = [
  { id: "pessoas", desc: "a photographic scene with real people in context (lifestyle), human-centered" },
  { id: "objeto", desc: "a close-up of a single product/object, still life, clean background" },
  { id: "ilustracao", desc: "a modern flat vector illustration, clean shapes" },
  { id: "3d", desc: "a stylized 3D render, soft materials, studio lighting" },
  { id: "foto", desc: "a realistic environmental photo / scene with depth of field" },
  { id: "minimalista", desc: "a minimalist/abstract composition, geometric shapes, lots of negative space" },
  { id: "conceitual", desc: "a conceptual editorial image, metaphor-driven, bold and modern" },
];

const TEXT_MODEL = "gpt-4o-mini";
const IMAGE_MODEL = "gpt-image-1";
const BUCKET = "posts";
const CONTEXT_SIZE = 6;

const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;
const PROXY_SECRET = Deno.env.get("PROXY_SECRET") ?? "";
const ACCESS_KEY = Deno.env.get("ACCESS_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

// ───────────────────────────── helpers ─────────────────────────────
function html(body: string, status = 200): Response {
  const h = new Headers();
  h.set("Content-Type", "application/xhtml+xml; charset=utf-8");
  return new Response(body, { status, headers: h });
}
function redirect(path: string): Response {
  const h = new Headers();
  h.set("Location", path);
  return new Response(null, { status: 302, headers: h });
}
function esc(s: string): string {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));
}
const kq = (k: string) => (k ? `&key=${encodeURIComponent(k)}` : "");
const kqh = (k: string) => (k ? `&amp;key=${encodeURIComponent(k)}` : "");

async function analyzeReferences(): Promise<string> {
  const imgs = (BRAND.referenceImages ?? []).filter(Boolean).slice(0, 5);
  if (!imgs.length) return "";
  try {
    const content: unknown[] = [{
      type: "text",
      text: "Analise estas imagens de referência (o estilo visual que a marca quer seguir). Descreva em 3-5 linhas, objetivo, em pt-BR: paleta de cores, tipo de imagem, composição/enquadramento, mood e elementos recorrentes.",
    }];
    for (const url of imgs) content.push({ type: "image_url", image_url: { url } });
    const v = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({ model: TEXT_MODEL, max_tokens: 320, messages: [{ role: "user", content }] }),
    });
    if (!v.ok) return "";
    const vj = await v.json();
    return (vj.choices?.[0]?.message?.content ?? "").trim();
  } catch {
    return "";
  }
}

async function generateContent(approvedCaptions: string[], styleBrief: string, tipoDesc: string): Promise<{ caption: string; image_prompt: string }> {
  const exemplos = approvedCaptions.length
    ? `Posts ANTERIORES aprovados (mantenha a pegada, sem repetir):\n- ${approvedCaptions.join("\n- ")}`
    : "Ainda não há posts aprovados; defina um bom padrão inicial.";
  const ref = styleBrief
    ? `Estilo visual da marca (extraído por visão das imagens de referência):\n"""${styleBrief}"""`
    : `Sem referência visual; siga a estética da marca.`;
  const system = `Você é o social media de "${BRAND.name}".
Nicho: ${BRAND.niche}. Público: ${BRAND.audience}. Tom: ${BRAND.tone}.
${ref}
Gere UM post para o Instagram. Responda SOMENTE em JSON válido com:
- "caption": legenda em pt-BR (1-2 emojis no máximo e 3-5 hashtags no fim).
- "image_prompt": descrição em INGLÊS da imagem. A imagem DEVE ser: ${tipoDesc}. Aplique o mood/composição da referência e use a PALETA DA MARCA (${BRAND.colors.accent}, ${BRAND.colors.bg}) com destaque. SEM nenhum texto/letras/logos na imagem. Formato quadrado, alta qualidade.`;

  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: TEXT_MODEL,
      messages: [{ role: "system", content: system }, { role: "user", content: `${exemplos}\n\nGere o próximo post agora.` }],
      response_format: { type: "json_object" },
      temperature: 0.9,
    }),
  });
  if (!r.ok) throw new Error("OpenAI (texto): " + (await r.text()));
  const data = await r.json();
  const parsed = JSON.parse(data.choices[0].message.content);
  return { caption: String(parsed.caption || "").trim(), image_prompt: String(parsed.image_prompt || "").trim() };
}

async function generateImage(prompt: string): Promise<Uint8Array> {
  const r = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({ model: IMAGE_MODEL, prompt, size: "1024x1024", n: 1 }),
  });
  if (!r.ok) throw new Error("OpenAI (imagem): " + (await r.text()));
  const data = await r.json();
  return Uint8Array.from(atob(data.data[0].b64_json as string), (c) => c.charCodeAt(0));
}

// ───────────────────────────── ações ─────────────────────────────
async function generate(key: string, tipoId?: string): Promise<Response> {
  const tipo = TYPES.find((t) => t.id === tipoId) ?? TYPES[Math.floor(Math.random() * TYPES.length)];
  const [aprovadosRes, styleBrief] = await Promise.all([
    supabase.from("posts").select("caption").eq("status", "aprovado").order("created_at", { ascending: false }).limit(CONTEXT_SIZE),
    analyzeReferences(),
  ]);
  const context = (aprovadosRes.data ?? []).map((p) => p.caption);
  const { caption, image_prompt } = await generateContent(context, styleBrief, tipo.desc);
  const bytes = await generateImage(image_prompt);
  const { data: inserted, error } = await supabase
    .from("posts").insert({ caption, image_prompt: `[${tipo.id}] ${image_prompt}`, status: "pendente" }).select("id").single();
  if (error) throw new Error("insert: " + error.message);
  const id = inserted.id;
  const path = `${id}.png`;
  const up = await supabase.storage.from(BUCKET).upload(path, bytes, { contentType: "image/png", upsert: true });
  if (up.error) throw new Error("upload: " + up.error.message);
  await supabase.from("posts").update({ image_path: path }).eq("id", id);
  return redirect(`?id=${id}${kq(key)}`);
}

async function renderCard(id: string, key: string, flash = ""): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("*").eq("id", id).single();
  if (!post) return html(page("<h2>Post não encontrado.</h2>"), 404);

  let imgUrl = "";
  if (post.image_path) {
    const signed = await supabase.storage.from(BUCKET).createSignedUrl(post.image_path, 3600);
    imgUrl = signed.data?.signedUrl ?? "";
  }
  const logo = BRAND.logoUrl;
  const statusColor = post.status === "aprovado" ? "#16a34a" : post.status === "descartado" ? "#dc2626" : "#9aa0a6";
  const handle = (BRAND.name.toLowerCase().replace(/\s+/g, "").replace(/[^a-z0-9._]/g, "")) || "marca";
  const likes = String(120 + (Number(post.id) * 137) % 4800).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const comments = 3 + (Number(post.id) * 7) % 60;
  const ic = (path: string, w = 25) =>
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${w}" height="${w}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
  const heart = ic('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>');
  const bubble = ic('<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5z"/>');
  const send = ic('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>');
  const save = ic('<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>');

  const card = `
    ${flash ? `<div class="flash">${esc(flash)}</div>` : ""}
    <div class="phone">
      <div class="app-bar"><span class="wordmark">Instagram</span><span class="ic">${heart}${send}</span></div>
      <div class="ig-head">
        <span class="ig-ring"><span class="ig-ava">${logo ? `<img src="${esc(logo)}" alt=""/>` : esc((BRAND.name[0] || "M").toUpperCase())}</span></span>
        <span class="ig-id"><span class="ig-user">${esc(handle)}</span><span class="ig-loc">Patrocinado</span></span>
        <span class="ig-more">⋯</span>
      </div>
      <div class="ig-imgwrap">
        ${imgUrl ? `<img class="ig-img" src="${esc(imgUrl)}" alt="post"/>` : `<div class="ig-img ig-noimg">gerando imagem…</div>`}
        ${logo ? `<img class="logo-wm" src="${esc(logo)}" alt=""/>` : ""}
      </div>
      <div class="ig-actions"><span class="left">${heart}${bubble}${send}</span>${save}</div>
      <div class="ig-likes">${likes} curtidas</div>
      <div class="ig-cap"><span class="ig-user">${esc(handle)}</span>${esc(post.caption).replace(/\n/g, "<br/>")}</div>
      <div class="ig-comments">Ver todos os ${comments} comentários</div>
      <div class="ig-time">há 2 horas</div>
    </div>
    <div class="tool">
      <span class="status-pill" style="color:${statusColor}">● ${esc(post.status)}</span>
      <div class="actions">
        <a class="btn ok" href="?approve=${post.id}${kqh(key)}">✓ Aprovar</a>
        <a class="btn no" href="?reject=${post.id}${kqh(key)}">✕ Descartar</a>
        ${post.image_path ? `<a class="btn ghost" href="?dl=img&amp;id=${post.id}${kqh(key)}">⬇ Imagem</a>` : ""}
        <a class="btn ghost" href="?dl=txt&amp;id=${post.id}${kqh(key)}">⬇ Legenda</a>
        <a class="btn solid" href="?${key ? `key=${encodeURIComponent(key)}` : ""}">↻ Gerar outro</a>
      </div>
    </div>`;
  return html(page(card));
}

async function setStatus(id: string, status: "aprovado" | "descartado", key: string): Promise<Response> {
  await supabase.from("posts").update({ status }).eq("id", id);
  const flash = status === "aprovado" ? "Aprovado — vai virar referência dos próximos." : "Descartado.";
  return redirect(`?id=${id}${kq(key)}&flash=${encodeURIComponent(flash)}`);
}

async function download(kind: string, id: string): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("caption,image_path").eq("id", id).single();
  if (!post) return new Response("não encontrado", { status: 404 });
  if (kind === "txt") {
    const h = new Headers();
    h.set("Content-Type", "application/octet-stream");
    h.set("Content-Disposition", `attachment; filename="post-${id}.txt"`);
    return new Response(post.caption ?? "", { status: 200, headers: h });
  }
  if (!post.image_path) return new Response("sem imagem", { status: 404 });
  const dl = await supabase.storage.from(BUCKET).download(post.image_path);
  if (dl.error || !dl.data) return new Response("erro ao baixar", { status: 500 });
  const buf = await dl.data.arrayBuffer();
  const h = new Headers();
  h.set("Content-Type", "image/png");
  h.set("Content-Disposition", `attachment; filename="post-${id}.png"`);
  return new Response(buf, { status: 200, headers: h });
}

function page(inner: string): string {
  return `<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-BR" xml:lang="pt-BR"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/><title>${esc(BRAND.name)} · gerador de posts</title>
<style>/*<![CDATA[*/
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;background:#fafafa;color:#0a0a0a;font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;gap:14px;padding:18px 12px}
  .phone{width:100%;max-width:430px;background:#fff;border:1px solid #dbdbdb;border-radius:16px;overflow:hidden;box-shadow:0 14px 44px -18px rgba(0,0,0,.3)}
  .app-bar{display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-bottom:1px solid #efefef}
  .app-bar .wordmark{font-size:20px;font-weight:700;font-style:italic;letter-spacing:-.02em}
  .app-bar .ic{display:flex;gap:16px;color:#262626}
  .ig-head{display:flex;align-items:center;gap:10px;padding:9px 14px}
  .ig-ring{padding:2px;border-radius:50%;background:linear-gradient(45deg,#feda75,#fa7e1e,#d62976,#962fbf,#4f5bd5)}
  .ig-ava{width:30px;height:30px;border-radius:50%;background:#fff;border:2px solid #fff;color:#262626;display:grid;place-items:center;font-weight:700;font-size:12px;overflow:hidden}
  .ig-ava img{width:100%;height:100%;object-fit:cover;border-radius:50%}
  .ig-id{flex:1;line-height:1.15}
  .ig-id .ig-user{display:block}
  .ig-user{font-weight:600;font-size:13px;color:#262626}
  .ig-loc{display:block;font-size:11px;color:#737373}
  .ig-more{color:#262626;font-size:20px;line-height:1;font-weight:700}
  .ig-imgwrap{position:relative;width:100%}
  .ig-img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:#eee}
  .ig-noimg{display:grid;place-items:center;color:#999;aspect-ratio:1/1;font-size:13px}
  .logo-wm{position:absolute;right:12px;bottom:12px;height:40px;max-width:42%;object-fit:contain;filter:drop-shadow(0 2px 7px rgba(0,0,0,.55));opacity:.96}
  .ig-actions{display:flex;align-items:center;justify-content:space-between;padding:8px 13px 4px;color:#262626}
  .ig-actions .left{display:flex;gap:13px}
  .ig-likes{padding:2px 14px;font-weight:600;font-size:14px}
  .ig-cap{padding:2px 14px;font-size:14px;line-height:1.45}
  .ig-cap .ig-user{margin-right:5px}
  .ig-comments{padding:5px 14px 0;font-size:14px;color:#737373}
  .ig-time{padding:3px 14px 14px;font-size:10px;text-transform:uppercase;letter-spacing:.03em;color:#999}
  .tool{display:flex;flex-direction:column;align-items:center;gap:11px;width:100%;max-width:430px}
  .status-pill{font-size:11px;text-transform:uppercase;letter-spacing:.05em;font-weight:700;padding:4px 12px;border-radius:999px;background:#efefef}
  .actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
  .btn{padding:9px 14px;border-radius:10px;font-weight:600;font-size:13.5px;text-decoration:none;cursor:pointer;border:1px solid transparent}
  .btn.ok{background:#16a34a;color:#fff}
  .btn.no{background:#dc2626;color:#fff}
  .btn.ghost{background:#fff;color:#262626;border:1px solid #dbdbdb}
  .btn.solid{background:#0095f6;color:#fff}
  .flash{width:100%;max-width:430px;background:#eafff0;border:1px solid #16a34a;color:#13683a;padding:10px 14px;border-radius:10px;font-weight:600;text-align:center}
  h2{text-align:center}
/*]]>*/</style></head><body>${inner}</body></html>`;
}

// ───────────────────────────── router ─────────────────────────────
Deno.serve(async (req) => {
  const url = new URL(req.url);
  const p = url.searchParams;
  const key = p.get("key") ?? "";
  const okHeader = PROXY_SECRET && req.headers.get("x-proxy-secret") === PROXY_SECRET;
  const okKey = ACCESS_KEY && key === ACCESS_KEY;
  const gated = Boolean(PROXY_SECRET || ACCESS_KEY);
  if (gated && !okHeader && !okKey) {
    return html(page(`<h2>🔒 acesso restrito</h2><p style="text-align:center">esta função só responde através do proxy autorizado.</p>`), 403);
  }
  try {
    if (p.get("dl")) return await download(p.get("dl")!, p.get("id") ?? "");
    if (p.get("approve")) return await setStatus(p.get("approve")!, "aprovado", key);
    if (p.get("reject")) return await setStatus(p.get("reject")!, "descartado", key);
    if (p.get("id")) return await renderCard(p.get("id")!, key, p.get("flash") ?? "");
    return await generate(key, p.get("tipo") ?? undefined);
  } catch (e) {
    return html(page(`<h2>⚠ Erro</h2><pre style="white-space:pre-wrap;text-align:left">${esc(String((e as Error).message))}</pre>`), 500);
  }
});
