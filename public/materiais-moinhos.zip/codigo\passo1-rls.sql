-- ============================================================
-- PASSO 1 do lab — o banco com regra de acesso (RLS)
-- Exatamente o que foi mostrado ao vivo. Cole no SQL Editor do Supabase.
-- Exemplo genérico: tabela de PEDIDOS, cada usuário só vê os seus.
-- ============================================================

-- 1) A tabela. user_id amarra cada registro ao dono (o usuário logado).
create table if not exists public.pedidos (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  descricao   text not null,
  valor       numeric,
  status      text not null default 'aberto',
  created_at  timestamptz not null default now()
);

-- 2) LIGA a regra de acesso. Sem esta linha, a tabela fica aberta.
alter table public.pedidos enable row level security;

-- 3) A policy: "cada um só vê o que é dele" (o coração do passo 1).
create policy "meus_pedidos_select" on public.pedidos
  for select to authenticated
  using (user_id = auth.uid());

-- 4) Escrever também só como dono (as DUAS travas: quais linhas + não passar pra outro dono).
create policy "meus_pedidos_insert" on public.pedidos
  for insert to authenticated
  with check (user_id = auth.uid());

create policy "meus_pedidos_update" on public.pedidos
  for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy "meus_pedidos_delete" on public.pedidos
  for delete to authenticated
  using (user_id = auth.uid());

-- ============================================================
-- COMO SABER QUE DEU CERTO
-- Logado como o usuário A, tente ler o registro do usuário B:
--   select * from public.pedidos where user_id <> auth.uid();
-- Deve voltar VAZIO. Se voltar dado, a policy não está pegando — revise.
-- ============================================================
