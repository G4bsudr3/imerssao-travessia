-- ============================================================
-- PASSO 1 do lab — o banco com regra de acesso (RLS)
-- Exatamente o que foi mostrado ao vivo. Cole no SQL Editor do Supabase.
-- Framing de saúde: tabela de PACIENTES, cada usuário só vê os seus.
-- ============================================================

-- 1) A tabela. user_id amarra cada registro ao dono (o profissional/usuário logado).
create table if not exists public.pacientes (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  nome        text not null,
  telefone    text,
  observacao  text,                              -- dado sensível: trate com cuidado
  created_at  timestamptz not null default now()
);

-- 2) LIGA a regra de acesso. Sem esta linha, a tabela fica aberta.
alter table public.pacientes enable row level security;

-- 3) A policy: "cada um só vê o que é dele" (o coração do passo 1).
create policy "meus_pacientes_select" on public.pacientes
  for select to authenticated
  using (user_id = auth.uid());

-- 4) Escrever também só como dono (as DUAS travas: quais linhas + não passar pra outro dono).
create policy "meus_pacientes_insert" on public.pacientes
  for insert to authenticated
  with check (user_id = auth.uid());

create policy "meus_pacientes_update" on public.pacientes
  for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy "meus_pacientes_delete" on public.pacientes
  for delete to authenticated
  using (user_id = auth.uid());

-- ============================================================
-- COMO SABER QUE DEU CERTO
-- Logado como o usuário A, tente ler o registro do usuário B:
--   select * from public.pacientes where user_id <> auth.uid();
-- Deve voltar VAZIO. Se voltar dado, a policy não está pegando — revise.
-- ============================================================
