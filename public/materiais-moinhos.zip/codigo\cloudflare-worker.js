// Cloudflare Worker — proxy seguro na frente da Edge Function (Supabase).
//
// Por quê: o Supabase rebaixa HTML pra text/plain no domínio *.supabase.co
// (anti-phishing). Este Worker faz proxy e devolve como text/html (renderiza),
// ESCONDE a origem e injeta um HEADER SECRETO que só ele conhece — a função só
// responde a quem manda esse header (acesso direto = 403). É também onde você
// liga rate limit / WAF no painel da Cloudflare.
//
// CONFIGURE no painel do Worker (Settings → Variables and Secrets), ou aqui:
//   UPSTREAM      = https://SEU_REF.supabase.co/functions/v1/post-generator
//   PROXY_SECRET  = (invente um segredo forte; o MESMO valor do secret PROXY_SECRET na função)

const DEFAULT_UPSTREAM = "https://SEU_REF.supabase.co/functions/v1/post-generator";
const DEFAULT_SECRET = "TROQUE-POR-UM-SEGREDO-FORTE";

export default {
  async fetch(req, env) {
    const UPSTREAM = env.UPSTREAM || DEFAULT_UPSTREAM;
    const PROXY_SECRET = env.PROXY_SECRET || DEFAULT_SECRET;

    const reqUrl = new URL(req.url);

    // monta a URL da função com os mesmos parâmetros (sem chave na URL)
    const up = new URL(UPSTREAM);
    for (const [k, v] of reqUrl.searchParams) if (k !== "key") up.searchParams.set(k, v);

    // o segredo vai no HEADER — só este Worker conhece. Acesso direto à função = 403.
    const upstream = await fetch(up.toString(), {
      headers: { "x-proxy-secret": PROXY_SECRET },
      redirect: "manual",
    });

    // repassa redirects (302 ?id=...) reescrevendo pro domínio do Worker
    if (upstream.status >= 300 && upstream.status < 400) {
      const loc = upstream.headers.get("location") || "";
      const locUrl = new URL(loc, UPSTREAM);
      const out = new URL(reqUrl.origin + reqUrl.pathname);
      for (const [k, v] of locUrl.searchParams) if (k !== "key") out.searchParams.set(k, v);
      return Response.redirect(out.toString(), 302);
    }

    // downloads (imagem/legenda): repassa o arquivo com content-type + disposition do upstream
    const cd = upstream.headers.get("content-disposition");
    if (cd) {
      const h = new Headers();
      h.set("content-type", upstream.headers.get("content-type") || "application/octet-stream");
      h.set("content-disposition", cd);
      return new Response(upstream.body, { status: upstream.status, headers: h });
    }

    // página: re-serve como text/html (corrige o rebaixamento do Supabase)
    const body = await upstream.text();
    return new Response(body, {
      status: upstream.status,
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  },
};
