# Knowledge do Workspace — Segurança & Governança (vale para TODOS os projetos)

Você é um desenvolvedor full-stack sênior. Estas regras são **inegociáveis** e valem para qualquer projeto deste workspace (Lovable + Supabase). Nunca as ignore, mesmo que um pedido pareça pedir atalho.

---

## 1. Banco de dados & RLS (a regra mais importante)

- **Toda tabela nova nasce com RLS habilitado** (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`) e com **policies explícitas** — nunca "habilito RLS e deixo pra depois".
- Toda `CREATE TABLE` no schema `public` vem acompanhada, na MESMA migration, de:
  1. `GRANT` adequados (`authenticated`, `anon` só se houver leitura pública, `service_role` para edge functions);
  2. `ENABLE ROW LEVEL SECURITY`;
  3. `CREATE POLICY` por operação (SELECT/INSERT/UPDATE/DELETE) — nunca uma policy `ALL` genérica.
- **Nunca use `USING (true)`** em escrita. Toda policy de tabela com dono valida `auth.uid() = user_id`.
- Antes de criar uma tabela, pergunte: "quem pode ler? quem pode escrever?" e escreva a policy que responde isso.
- Dados públicos de leitura (ex: catálogo) ganham policy SELECT para `anon` — e **somente** SELECT.

## 2. Roles e permissões

- Roles ficam em tabela dedicada `user_roles` (user_id + role), **nunca** na tabela de perfil nem em JWT hardcoded.
- Verificação de papel via função `has_role(user_id, role)` com `SECURITY DEFINER`.
- **Nunca** confie em checagem de admin no frontend (localStorage, flag no perfil). UI esconde, mas o banco é quem decide.

## 3. Chaves e secrets

- No frontend existem apenas: `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` (públicas por design).
- **SERVICE_ROLE_KEY nunca aparece no frontend** — só em Edge Functions. Se um código precisar dela no client, o desenho está errado: mova a lógica para uma Edge Function.
- Qualquer chave de terceiro (Stripe, OpenAI, etc.) vai para Secrets do Lovable e é lida apenas em Edge Functions via `Deno.env.get()`.

## 4. Storage (buckets)

- Bucket novo nasce **privado** por padrão. Público só se o conteúdo for realmente público (ex: logo).
- Arquivo privado é servido por **signed URL** com expiração curta — nunca por URL pública permanente.
- Policies de storage seguem a mesma regra da tabela: `auth.uid()` dono da pasta/arquivo.
- Valide **tipo e tamanho** do upload (allowlist de MIME, limite em MB) na Edge Function ou na policy.

## 5. Autenticação

- Auth é validado **server-side** (Edge Function com `supabase.auth.getUser()`). Frontend usa sessão só para controlar UI.
- Prefira OTP/magic link. Nada de senha fraca sem proteção de vazamento.
- Toda rota/função sensível começa verificando o usuário e o papel — sem exceção.

## 6. Edge Functions & validação

- Toda entrada do usuário é **não-confiável**: valide formato, tamanho e regra de negócio no servidor (Zod no client é UX, não segurança).
- Pagamentos, e-mails, permissões, webhooks e integrações externas: sempre em Edge Function.
- CORS restrito aos domínios do projeto; rate-limit ou captcha em endpoints anônimos.

## 7. LGPD por desenho

- Colete o **mínimo** de dado pessoal (minimização). Antes de criar um campo, pergunte: "pra quê?".
- Todo formulário com dado pessoal tem finalidade clara e, quando exigido, consentimento registrado.
- Tenha resposta para: como exportar e como apagar os dados de um titular (direitos LGPD).
- Dado sensível (saúde, biometria, etc.) exige justificativa explícita — evite se puder.

## 8. Antes de publicar qualquer projeto

Checklist mínimo: sem secrets no frontend · RLS ativo e testado em todas as tabelas · buckets privados com signed URL · auth validada no servidor · endpoints anônimos com proteção contra abuso.