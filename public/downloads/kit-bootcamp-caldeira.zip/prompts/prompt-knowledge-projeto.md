# Knowledge do Projeto — {{NOME_DO_PROJETO}}

> Projeto na stack Lovable + Supabase. Além das regras de segurança do workspace, este documento define a governança DESTE projeto. Atualize sempre que o escopo mudar.

## Contexto

- **O que é:** {{DESCREVA O PROJETO EM 1-2 FRASES — ex: "SaaS de agendamento para clínicas odontológicas"}}
- **Quem usa:** {{PAPÉIS DE USUÁRIO — ex: admin da clínica, recepcionista, paciente}}
- **Ambiente/domínio:** {{DOMÍNIO DE PRODUÇÃO — ex: app.minhaclinica.com.br}}

## Dados que este projeto guarda (inventário LGPD)

| Dado | Tabela/bucket | Sensível? | Base legal | Retenção |
|---|---|---|---|---|
| {{ex: nome, e-mail}} | {{profiles}} | não | {{execução de contrato}} | {{enquanto conta ativa}} |
| {{ex: CPF}} | {{patients}} | sim | {{obrigação legal}} | {{5 anos}} |
| {{ex: exame em PDF}} | bucket {{exames}} (privado) | sim | {{consentimento}} | {{20 anos}} |

Regra: este inventário é a fonte da verdade. Campo novo de dado pessoal só entra se estiver listado aqui.

## Modelo de acesso (quem vê o quê)

- **{{papel 1 — ex: admin}}**: {{o que pode ler/escrever}}
- **{{papel 2 — ex: recepcionista}}**: {{o que pode ler/escrever}}
- **{{papel 3 — ex: paciente}}**: vê apenas os próprios dados (policy `auth.uid() = user_id`)
- **Anônimo (sem login)**: {{nada / apenas X}}

Ao criar ou alterar tabelas, escreva as policies RLS que implementam exatamente esta matriz — e me mostre o SQL antes de aplicar.

## Buckets

| Bucket | Público? | Quem escreve | Quem lê |
|---|---|---|---|
| {{ex: avatars}} | {{sim}} | dono do perfil | todos |
| {{ex: exames}} | {{não}} | {{recepcionista}} | {{paciente dono + clínica, via signed URL 5 min}} |

## Edge Functions previstas

- {{ex: `criar-agendamento` — valida conflito de horário e permissão, escreve no banco}}
- {{ex: `webhook-pagamento` — valida assinatura do provedor, atualiza status}}
- Regra: lógica que mexe com dinheiro, permissão ou dado sensível **só existe aqui**, nunca no frontend.

## Dívidas proibidas neste projeto

1. Tabela sem RLS ou policy `USING (true)` em escrita.
2. Service role key ou qualquer secret fora dos Secrets/Edge Functions.
3. Bucket privado servido por URL pública.
4. Checagem de papel/admin só no frontend.
5. Campo de dado pessoal fora do inventário acima.
6. Endpoint anônimo sem rate-limit/captcha.

Se um pedido meu conflitar com estas regras, **aponte o conflito antes de implementar**.