// post-generator-open — VERSÃO ABERTA pra DEMONSTRAR (sem proxy, sem chave, sem Worker).
//
// Renderiza o card como SVG (image/svg+xml não é rebaixado pelo Supabase), então abre
// DIRETO na URL do Supabase. NÃO tem trava de acesso: qualquer um com a URL chama e gasta
// seus créditos de IA — é de propósito, pra mostrar o "antes" e depois comparar com a versão
// travada (post-generator + Worker, com header secreto).
//
// Deploy: crie a função, cole este código, DESLIGUE o "Verify JWT". Abra:
//   https://SEU_REF.supabase.co/functions/v1/post-generator-open

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ╔══════════════════════════════════════════════════════════════╗
// ║  CONFIG — edite com a SUA identidade                          ║
// ╚══════════════════════════════════════════════════════════════╝
const BRAND = {
  name: "Sua Marca",
  niche: "vibe coding, IA e segurança para builders",
  tone: "didático, direto e descontraído, em pt-BR",
  audience: "devs e founders que constroem com IA",
  colors: { bg: "#0e1726", accent: "#9fe870", text: "#ffffff" },
  logoUrl: "",
  inspirations: ["@exemplo_inspira1", "@exemplo_inspira2"],
};

const TEXT_MODEL = "gpt-4o-mini";
const IMAGE_MODEL = "gpt-image-1";
const BUCKET = "posts";
const CONTEXT_SIZE = 6;

const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;
const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

// ───────────────────────────── helpers ─────────────────────────────
function svg(body: string, status = 200): Response {
  const h = new Headers();
  h.set("Content-Type", "image/svg+xml; charset=utf-8");
  return new Response(body, { status, headers: h });
}
function redirect(path: string): Response {
  const h = new Headers();
  h.set("Location", path);
  return new Response(null, { status: 302, headers: h });
}
function esc(s: string): string {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));
}

// ── Firecrawl + visão: analisa o estilo das publicações de inspiração ──
async function analyzeInspiration(): Promise<string> {
  const handle = (BRAND.inspirations[0] || "").replace(/^@/, "");
  if (!handle || !FIRECRAWL_API_KEY) return "";
  try {
    const fc = await fetch("https://api.firecrawl.dev/v1/scrape", {
      method: "POST",
      headers: { authorization: `Bearer ${FIRECRAWL_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({ url: `https://www.instagram.com/${handle}/`, formats: ["screenshot"], waitFor: 3500 }),
    });
    if (!fc.ok) return "";
    const fj = await fc.json();
    const shot = fj?.data?.screenshot;
    if (!shot) return "";
    const v = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        max_tokens: 320,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: `Esta é a página do Instagram de @${handle}. Descreva em 4-6 linhas o ESTILO visual recorrente das publicações: paleta de cores, tipo de imagem (foto/ilustração/3D/render), composição, mood e temas. Objetivo, em pt-BR. Se a página for um login/erro/sem conteúdo, responda só: INDISPONIVEL` },
            { type: "image_url", image_url: { url: shot } },
          ],
        }],
      }),
    });
    if (!v.ok) return "";
    const vj = await v.json();
    const brief = (vj.choices?.[0]?.message?.content ?? "").trim();
    return brief.includes("INDISPONIVEL") ? "" : brief;
  } catch {
    return "";
  }
}

async function generateContent(approvedCaptions: string[], styleBrief: string): Promise<{ caption: string; image_prompt: string }> {
  const exemplos = approvedCaptions.length
    ? `Posts ANTERIORES aprovados (mantenha a mesma pegada, sem repetir):\n- ${approvedCaptions.join("\n- ")}`
    : "Ainda não há posts aprovados; defina um bom padrão inicial.";
  const ref = styleBrief
    ? `Referência visual REAL extraída do perfil de inspiração (analisada por visão da IA):\n"""${styleBrief}"""\nUse a COMPOSIÇÃO e o MOOD dessa referência. MAS as cores da marca (${BRAND.colors.accent} e ${BRAND.colors.bg}) têm PRIORIDADE sobre as cores da referência.`
    : `Sem referência visual externa disponível; siga a estética da marca (cores ${BRAND.colors.accent} e ${BRAND.colors.bg}).`;
  const system = `Você é o social media de "${BRAND.name}".
Nicho: ${BRAND.niche}. Público: ${BRAND.audience}. Tom: ${BRAND.tone}.
Perfis de referência: ${BRAND.inspirations.join(", ")}.
${ref}
Gere UM post para o Instagram. Responda SOMENTE em JSON válido com as chaves:
- "caption": a legenda em pt-BR (1-2 emojis no máximo e 3-5 hashtags no fim).
- "image_prompt": descrição em INGLÊS para gerar a imagem; aplique a composição/mood da referência, mas com a PALETA DA MARCA (${BRAND.colors.accent}, ${BRAND.colors.bg}) em destaque; SEM texto/letras na imagem; quadrada, clean e moderna.`;

  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: `${exemplos}\n\nGere o próximo post agora.` },
      ],
      response_format: { type: "json_object" },
      temperature: 0.9,
    }),
  });
  if (!r.ok) throw new Error("OpenAI (texto): " + (await r.text()));
  const data = await r.json();
  const parsed = JSON.parse(data.choices[0].message.content);
  return { caption: String(parsed.caption || "").trim(), image_prompt: String(parsed.image_prompt || "").trim() };
}

async function generateImage(prompt: string): Promise<Uint8Array> {
  const r = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({ model: IMAGE_MODEL, prompt, size: "1024x1024", n: 1 }),
  });
  if (!r.ok) throw new Error("OpenAI (imagem): " + (await r.text()));
  const data = await r.json();
  const b64 = data.data[0].b64_json as string;
  return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
}

function toDataUri(buf: Uint8Array): string {
  let bin = "";
  for (let i = 0; i < buf.length; i++) bin += String.fromCharCode(buf[i]);
  return "data:image/png;base64," + btoa(bin);
}

// ───────────────────────────── ações ─────────────────────────────
async function generate(): Promise<Response> {
  const [aprovadosRes, styleBrief] = await Promise.all([
    supabase.from("posts").select("caption").eq("status", "aprovado")
      .order("created_at", { ascending: false }).limit(CONTEXT_SIZE),
    analyzeInspiration(),
  ]);
  const context = (aprovadosRes.data ?? []).map((p) => p.caption);
  const { caption, image_prompt } = await generateContent(context, styleBrief);
  const bytes = await generateImage(image_prompt);
  const { data: inserted, error } = await supabase
    .from("posts").insert({ caption, image_prompt, status: "pendente" }).select("id").single();
  if (error) throw new Error("insert: " + error.message);
  const id = inserted.id;
  const path = `${id}.png`;
  const up = await supabase.storage.from(BUCKET).upload(path, bytes, { contentType: "image/png", upsert: true });
  if (up.error) throw new Error("upload: " + up.error.message);
  await supabase.from("posts").update({ image_path: path }).eq("id", id);
  return redirect(`?id=${id}`);
}

async function renderCard(id: string, flash = ""): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("*").eq("id", id).single();
  if (!post) return svg(page("<h2>Post não encontrado.</h2>"), 404);

  let imgData = "";
  if (post.image_path) {
    const dl = await supabase.storage.from(BUCKET).download(post.image_path);
    if (dl.data) imgData = toDataUri(new Uint8Array(await dl.data.arrayBuffer()));
  }
  const statusColor = post.status === "aprovado" ? "#16a34a" : post.status === "descartado" ? "#dc2626" : "#9aa0a6";
  const handle = (BRAND.name.toLowerCase().replace(/\s+/g, "").replace(/[^a-z0-9._]/g, "")) || "marca";
  const likes = String(120 + (Number(post.id) * 137) % 4800).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const comments = 3 + (Number(post.id) * 7) % 60;
  const ic = (path: string, w = 25) =>
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${w}" height="${w}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
  const heart = ic('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>');
  const bubble = ic('<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5z"/>');
  const send = ic('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>');
  const save = ic('<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>');

  const card = `
    ${flash ? `<div class="flash">${esc(flash)}</div>` : ""}
    <div class="phone">
      <div class="app-bar"><span class="wordmark">Instagram</span><span class="ic">${heart}${send}</span></div>
      <div class="ig-head">
        <span class="ig-ring"><span class="ig-ava">${BRAND.logoUrl ? `<img src="${esc(BRAND.logoUrl)}" alt=""/>` : esc((BRAND.name[0] || "M").toUpperCase())}</span></span>
        <span class="ig-id"><span class="ig-user">${esc(handle)}</span><span class="ig-loc">Patrocinado</span></span>
        <span class="ig-more">⋯</span>
      </div>
      ${imgData ? `<img class="ig-img" src="${imgData}" alt="post"/>` : `<div class="ig-img ig-noimg">gerando imagem…</div>`}
      <div class="ig-actions"><span class="left">${heart}${bubble}${send}</span>${save}</div>
      <div class="ig-likes">${likes} curtidas</div>
      <div class="ig-cap"><span class="ig-user">${esc(handle)}</span>${esc(post.caption).replace(/\n/g, "<br/>")}</div>
      <div class="ig-comments">Ver todos os ${comments} comentários</div>
      <div class="ig-time">há 2 horas</div>
    </div>
    <div class="tool">
      <span class="status-pill" style="color:${statusColor}">● ${esc(post.status)}</span>
      <div class="actions">
        <a class="btn ok" href="?approve=${post.id}">✓ Aprovar</a>
        <a class="btn no" href="?reject=${post.id}">✕ Descartar</a>
        ${post.image_path ? `<a class="btn ghost" href="?dl=img&amp;id=${post.id}">⬇ Imagem</a>` : ""}
        <a class="btn ghost" href="?dl=txt&amp;id=${post.id}">⬇ Legenda</a>
        <a class="btn solid" href="?">↻ Gerar outro</a>
      </div>
    </div>`;
  return svg(page(card));
}

async function setStatus(id: string, status: "aprovado" | "descartado"): Promise<Response> {
  await supabase.from("posts").update({ status }).eq("id", id);
  const flash = status === "aprovado" ? "Aprovado — vai virar referência dos próximos." : "Descartado.";
  return redirect(`?id=${id}&flash=${encodeURIComponent(flash)}`);
}

async function download(kind: string, id: string): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("caption,image_path").eq("id", id).single();
  if (!post) return new Response("não encontrado", { status: 404 });
  if (kind === "txt") {
    const h = new Headers();
    h.set("Content-Type", "application/octet-stream");
    h.set("Content-Disposition", `attachment; filename="post-${id}.txt"`);
    return new Response(post.caption ?? "", { status: 200, headers: h });
  }
  if (!post.image_path) return new Response("sem imagem", { status: 404 });
  const dl = await supabase.storage.from(BUCKET).download(post.image_path);
  if (dl.error || !dl.data) return new Response("erro ao baixar", { status: 500 });
  const buf = await dl.data.arrayBuffer();
  const h = new Headers();
  h.set("Content-Type", "image/png");
  h.set("Content-Disposition", `attachment; filename="post-${id}.png"`);
  return new Response(buf, { status: 200, headers: h });
}

// ── SVG com o card HTML dentro de <foreignObject> ──
function page(inner: string): string {
  const W = 430, H = 920;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<rect width="${W}" height="${H}" fill="#fafafa"/>
<foreignObject x="0" y="0" width="${W}" height="${H}">
<div xmlns="http://www.w3.org/1999/xhtml" style="width:${W}px;min-height:${H}px;color:#0a0a0a;font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;gap:14px;padding:16px 10px">
<style>/*<![CDATA[*/
  *{box-sizing:border-box}
  .phone{width:100%;max-width:410px;background:#fff;border:1px solid #dbdbdb;border-radius:16px;overflow:hidden;box-shadow:0 14px 44px -18px rgba(0,0,0,.3)}
  .app-bar{display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-bottom:1px solid #efefef}
  .app-bar .wordmark{font-size:20px;font-weight:700;font-style:italic;letter-spacing:-.02em}
  .app-bar .ic{display:flex;gap:16px;color:#262626}
  .ig-head{display:flex;align-items:center;gap:10px;padding:9px 14px}
  .ig-ring{padding:2px;border-radius:50%;background:linear-gradient(45deg,#feda75,#fa7e1e,#d62976,#962fbf,#4f5bd5)}
  .ig-ava{width:30px;height:30px;border-radius:50%;background:#fff;border:2px solid #fff;color:#262626;display:grid;place-items:center;font-weight:700;font-size:12px;overflow:hidden}
  .ig-ava img{width:100%;height:100%;object-fit:cover;border-radius:50%}
  .ig-id{flex:1;line-height:1.15}
  .ig-id .ig-user{display:block}
  .ig-user{font-weight:600;font-size:13px;color:#262626}
  .ig-loc{display:block;font-size:11px;color:#737373}
  .ig-more{color:#262626;font-size:20px;line-height:1;font-weight:700}
  .ig-img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:#eee}
  .ig-noimg{display:grid;place-items:center;color:#999;aspect-ratio:1/1;font-size:13px}
  .ig-actions{display:flex;align-items:center;justify-content:space-between;padding:8px 13px 4px;color:#262626}
  .ig-actions .left{display:flex;gap:13px}
  .ig-likes{padding:2px 14px;font-weight:600;font-size:14px}
  .ig-cap{padding:2px 14px;font-size:14px;line-height:1.45}
  .ig-cap .ig-user{margin-right:5px}
  .ig-comments{padding:5px 14px 0;font-size:14px;color:#737373}
  .ig-time{padding:3px 14px 14px;font-size:10px;text-transform:uppercase;letter-spacing:.03em;color:#999}
  .tool{display:flex;flex-direction:column;align-items:center;gap:11px;width:100%;max-width:410px}
  .status-pill{font-size:11px;text-transform:uppercase;letter-spacing:.05em;font-weight:700;padding:4px 12px;border-radius:999px;background:#efefef}
  .actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
  .btn{padding:9px 14px;border-radius:10px;font-weight:600;font-size:13.5px;text-decoration:none;cursor:pointer;border:1px solid transparent}
  .btn.ok{background:#16a34a;color:#fff}
  .btn.no{background:#dc2626;color:#fff}
  .btn.ghost{background:#fff;color:#262626;border:1px solid #dbdbdb}
  .btn.solid{background:#0095f6;color:#fff}
  .flash{width:100%;max-width:410px;background:#eafff0;border:1px solid #16a34a;color:#13683a;padding:10px 14px;border-radius:10px;font-weight:600;text-align:center}
  h2{text-align:center}
/*]]>*/</style>
${inner}
</div>
</foreignObject>
</svg>`;
}

// ───────────────────────────── router (SEM trava de acesso) ─────────────────────────────
Deno.serve(async (req) => {
  const p = new URL(req.url).searchParams;
  try {
    if (p.get("dl")) return await download(p.get("dl")!, p.get("id") ?? "");
    if (p.get("approve")) return await setStatus(p.get("approve")!, "aprovado");
    if (p.get("reject")) return await setStatus(p.get("reject")!, "descartado");
    if (p.get("id")) return await renderCard(p.get("id")!, p.get("flash") ?? "");
    return await generate();
  } catch (e) {
    return svg(page(`<h2>⚠ Erro</h2><pre style="white-space:pre-wrap">${esc(String((e as Error).message))}</pre>`), 500);
  }
});
