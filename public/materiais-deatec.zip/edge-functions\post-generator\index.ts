// post-generator — Edge Function (Deno) do Supabase
// Automação pura: chamada via GET no navegador, gera um post de mídia social com IA
// (legenda + imagem), salva no Supabase e devolve um card estilo Instagram com
// Aprovar / Descartar / Baixar. O que você aprova vira contexto das próximas gerações.
//
// Segurança (o gancho do workshop):
//  - OPENAI_API_KEY vive só nos secrets da função (nunca no front).
//  - service_role é injetado pelo Supabase e usado só aqui no servidor.
//  - bucket de imagens é PRIVADO; o download usa URL assinada (expira).
//  - ponha o Cloudflare na frente do endpoint (rate limit / WAF / esconde origem).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ╔══════════════════════════════════════════════════════════════╗
// ║  CONFIG — edite com a SUA identidade                          ║
// ╚══════════════════════════════════════════════════════════════╝
const BRAND = {
  name: "Sua Marca",
  niche: "vibe coding, IA e segurança para builders",      // do que você fala
  tone: "didático, direto e descontraído, em pt-BR",        // tom de voz
  audience: "devs e founders que constroem com IA",         // público
  colors: { bg: "#0e1726", accent: "#9fe870", text: "#ffffff" }, // cores da marca
  logoUrl: "",                                              // URL pública da sua logo (opcional)
  inspirations: ["@exemplo_inspira1", "@exemplo_inspira2"], // perfis que te inspiram
};

const TEXT_MODEL = "gpt-4o-mini";
const IMAGE_MODEL = "gpt-image-1";
const BUCKET = "posts";
const CONTEXT_SIZE = 6; // quantos posts aprovados usar como referência de estilo

// ── env (injetado pelo Supabase / secrets) ──
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;
const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY") ?? "";
// Trava de acesso. Em produção, o ideal é o HEADER (só o Worker da Cloudflare envia):
//  - PROXY_SECRET: header "x-proxy-secret" que só o proxy autorizado conhece.
//  - ACCESS_KEY: fallback via ?key= (útil pra testar direto, sem o Worker).
const PROXY_SECRET = Deno.env.get("PROXY_SECRET") ?? "";
const ACCESS_KEY = Deno.env.get("ACCESS_KEY") ?? "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

// ───────────────────────────── helpers ─────────────────────────────
function html(body: string, status = 200): Response {
  const h = new Headers();
  // application/xhtml+xml renderiza no navegador E não é rebaixado pra text/plain
  // pelo gateway do Supabase (anti-phishing) — diferente de text/html.
  h.set("Content-Type", "application/xhtml+xml; charset=utf-8");
  return new Response(body, { status, headers: h });
}
function redirect(path: string): Response {
  const h = new Headers();
  h.set("Location", path);
  return new Response(null, { status: 302, headers: h });
}
function esc(s: string): string {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));
}
const kq = (k: string) => (k ? `&key=${encodeURIComponent(k)}` : "");        // header Location (& cru)
const kqh = (k: string) => (k ? `&amp;key=${encodeURIComponent(k)}` : "");   // href em XHTML (& escapado)

// ── Firecrawl + visão: analisa o estilo das publicações de inspiração ──
async function analyzeInspiration(): Promise<string> {
  const handle = (BRAND.inspirations[0] || "").replace(/^@/, "");
  if (!handle || !FIRECRAWL_API_KEY) return "";
  try {
    // 1) Firecrawl tira um screenshot do perfil (renderiza JS + proxies)
    const fc = await fetch("https://api.firecrawl.dev/v1/scrape", {
      method: "POST",
      headers: { authorization: `Bearer ${FIRECRAWL_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({ url: `https://www.instagram.com/${handle}/`, formats: ["screenshot"], waitFor: 3500 }),
    });
    if (!fc.ok) return "";
    const fj = await fc.json();
    const shot = fj?.data?.screenshot;
    if (!shot) return "";
    // 2) GPT-4o (visão) descreve o estilo recorrente das publicações
    const v = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        max_tokens: 320,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: `Esta é a página do Instagram de @${handle}. Descreva em 4-6 linhas o ESTILO visual recorrente das publicações: paleta de cores, tipo de imagem (foto/ilustração/3D/render), composição, mood e temas. Objetivo, em pt-BR. Se a página for um login/erro/sem conteúdo, responda só: INDISPONIVEL` },
            { type: "image_url", image_url: { url: shot } },
          ],
        }],
      }),
    });
    if (!v.ok) return "";
    const vj = await v.json();
    const brief = (vj.choices?.[0]?.message?.content ?? "").trim();
    return brief.includes("INDISPONIVEL") ? "" : brief;
  } catch {
    return "";
  }
}

// ── OpenAI: gera legenda + prompt de imagem (JSON) ──
async function generateContent(approvedCaptions: string[], styleBrief: string): Promise<{ caption: string; image_prompt: string }> {
  const exemplos = approvedCaptions.length
    ? `Posts ANTERIORES aprovados (mantenha a mesma pegada, sem repetir):\n- ${approvedCaptions.join("\n- ")}`
    : "Ainda não há posts aprovados; defina um bom padrão inicial.";

  const ref = styleBrief
    ? `Referência visual REAL extraída do perfil de inspiração (analisada por visão da IA):\n"""${styleBrief}"""\nUse a COMPOSIÇÃO e o MOOD dessa referência. MAS as cores da marca (${BRAND.colors.accent} e ${BRAND.colors.bg}) têm PRIORIDADE sobre as cores da referência.`
    : `Sem referência visual externa disponível; siga a estética da marca (cores ${BRAND.colors.accent} e ${BRAND.colors.bg}).`;
  const system = `Você é o social media de "${BRAND.name}".
Nicho: ${BRAND.niche}. Público: ${BRAND.audience}. Tom: ${BRAND.tone}.
Perfis de referência: ${BRAND.inspirations.join(", ")}.
${ref}
Gere UM post para o Instagram. Responda SOMENTE em JSON válido com as chaves:
- "caption": a legenda em pt-BR (1-2 emojis no máximo e 3-5 hashtags no fim).
- "image_prompt": descrição em INGLÊS para gerar a imagem; aplique a composição/mood da referência, mas com a PALETA DA MARCA (${BRAND.colors.accent}, ${BRAND.colors.bg}) em destaque; SEM texto/letras na imagem; quadrada, clean e moderna.`;

  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: TEXT_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: `${exemplos}\n\nGere o próximo post agora.` },
      ],
      response_format: { type: "json_object" },
      temperature: 0.9,
    }),
  });
  if (!r.ok) throw new Error("OpenAI (texto): " + (await r.text()));
  const data = await r.json();
  const parsed = JSON.parse(data.choices[0].message.content);
  return { caption: String(parsed.caption || "").trim(), image_prompt: String(parsed.image_prompt || "").trim() };
}

// ── OpenAI: gera a imagem (b64) ──
async function generateImage(prompt: string): Promise<Uint8Array> {
  const r = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({ model: IMAGE_MODEL, prompt, size: "1024x1024", n: 1 }),
  });
  if (!r.ok) throw new Error("OpenAI (imagem): " + (await r.text()));
  const data = await r.json();
  const b64 = data.data[0].b64_json as string;
  return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
}

// ───────────────────────────── ações ─────────────────────────────
async function generate(key: string): Promise<Response> {
  // 1) contexto em paralelo: posts aprovados (estilo próprio) + análise visual do
  //    perfil de inspiração via Firecrawl + visão GPT-4o
  const [aprovadosRes, styleBrief] = await Promise.all([
    supabase.from("posts").select("caption").eq("status", "aprovado")
      .order("created_at", { ascending: false }).limit(CONTEXT_SIZE),
    analyzeInspiration(),
  ]);
  const context = (aprovadosRes.data ?? []).map((p) => p.caption);

  // 2) legenda + prompt de imagem
  const { caption, image_prompt } = await generateContent(context, styleBrief);

  // 3) imagem
  const bytes = await generateImage(image_prompt);

  // 4) cria a linha (status pendente) e sobe a imagem
  const { data: inserted, error } = await supabase
    .from("posts").insert({ caption, image_prompt, status: "pendente" }).select("id").single();
  if (error) throw new Error("insert: " + error.message);
  const id = inserted.id;
  const path = `${id}.png`;
  const up = await supabase.storage.from(BUCKET).upload(path, bytes, { contentType: "image/png", upsert: true });
  if (up.error) throw new Error("upload: " + up.error.message);
  await supabase.from("posts").update({ image_path: path }).eq("id", id);

  // 5) redireciona pro card
  return redirect(`?id=${id}${kq(key)}`);
}

async function renderCard(id: string, key: string, flash = ""): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("*").eq("id", id).single();
  if (!post) return html(page("<h2>Post não encontrado.</h2>"), 404);

  let imgUrl = "";
  if (post.image_path) {
    const signed = await supabase.storage.from(BUCKET).createSignedUrl(post.image_path, 3600);
    imgUrl = signed.data?.signedUrl ?? "";
  }
  const statusColor = post.status === "aprovado" ? "#16a34a" : post.status === "descartado" ? "#dc2626" : "#9aa0a6";

  const handle = (BRAND.name.toLowerCase().replace(/\s+/g, "").replace(/[^a-z0-9._]/g, "")) || "marca";
  const likes = String(120 + (Number(post.id) * 137) % 4800).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const comments = 3 + (Number(post.id) * 7) % 60;
  const ic = (path: string, w = 25) =>
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${w}" height="${w}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
  const heart = ic('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>');
  const bubble = ic('<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5z"/>');
  const send = ic('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>');
  const save = ic('<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>');

  const card = `
    ${flash ? `<div class="flash">${esc(flash)}</div>` : ""}
    <div class="phone">
      <div class="app-bar"><span class="wordmark">Instagram</span><span class="ic">${heart}${send}</span></div>
      <div class="ig-head">
        <span class="ig-ring"><span class="ig-ava">${BRAND.logoUrl ? `<img src="${esc(BRAND.logoUrl)}" alt=""/>` : esc((BRAND.name[0] || "M").toUpperCase())}</span></span>
        <span class="ig-id"><span class="ig-user">${esc(handle)}</span><span class="ig-loc">Patrocinado</span></span>
        <span class="ig-more">⋯</span>
      </div>
      ${imgUrl ? `<img class="ig-img" src="${esc(imgUrl)}" alt="post"/>` : `<div class="ig-img ig-noimg">gerando imagem…</div>`}
      <div class="ig-actions"><span class="left">${heart}${bubble}${send}</span>${save}</div>
      <div class="ig-likes">${likes} curtidas</div>
      <div class="ig-cap"><span class="ig-user">${esc(handle)}</span>${esc(post.caption).replace(/\n/g, "<br/>")}</div>
      <div class="ig-comments">Ver todos os ${comments} comentários</div>
      <div class="ig-time">há 2 horas</div>
    </div>
    <div class="tool">
      <span class="status-pill" style="color:${statusColor}">● ${esc(post.status)}</span>
      <div class="actions">
        <a class="btn ok" href="?approve=${post.id}${kqh(key)}">✓ Aprovar</a>
        <a class="btn no" href="?reject=${post.id}${kqh(key)}">✕ Descartar</a>
        ${imgUrl ? `<a class="btn ghost" href="?dl=img&amp;id=${post.id}${kqh(key)}">⬇ Imagem</a>` : ""}
        <a class="btn ghost" href="?dl=txt&amp;id=${post.id}${kqh(key)}">⬇ Legenda</a>
        <a class="btn solid" href="?${key ? `key=${encodeURIComponent(key)}` : ""}">↻ Gerar outro</a>
      </div>
    </div>`;
  return html(page(card));
}

async function setStatus(id: string, status: "aprovado" | "descartado", key: string): Promise<Response> {
  await supabase.from("posts").update({ status }).eq("id", id);
  const flash = status === "aprovado" ? "Aprovado — vai virar referência dos próximos." : "Descartado.";
  return redirect(`?id=${id}${kq(key)}&flash=${encodeURIComponent(flash)}`);
}

// ── download de verdade: força attachment (não abre em aba) ──
async function download(kind: string, id: string): Promise<Response> {
  const { data: post } = await supabase.from("posts").select("caption,image_path").eq("id", id).single();
  if (!post) return new Response("não encontrado", { status: 404 });

  if (kind === "txt") {
    const h = new Headers();
    h.set("Content-Type", "application/octet-stream");
    h.set("Content-Disposition", `attachment; filename="post-${id}.txt"`);
    return new Response(post.caption ?? "", { status: 200, headers: h });
  }
  // imagem
  if (!post.image_path) return new Response("sem imagem", { status: 404 });
  const dl = await supabase.storage.from(BUCKET).download(post.image_path);
  if (dl.error || !dl.data) return new Response("erro ao baixar", { status: 500 });
  const buf = await dl.data.arrayBuffer();
  const h = new Headers();
  h.set("Content-Type", "image/png");
  h.set("Content-Disposition", `attachment; filename="post-${id}.png"`);
  return new Response(buf, { status: 200, headers: h });
}

// ── shell HTML (estilo Instagram) ──
function page(inner: string): string {
  return `<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-BR" xml:lang="pt-BR"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/><title>${esc(BRAND.name)} · gerador de posts</title>
<style>/*<![CDATA[*/
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;background:#fafafa;color:#0a0a0a;font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;gap:16px;padding:22px 14px}
  .phone{width:100%;max-width:430px;background:#fff;border:1px solid #dbdbdb;border-radius:16px;overflow:hidden;box-shadow:0 14px 44px -18px rgba(0,0,0,.3)}
  .app-bar{display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-bottom:1px solid #efefef}
  .app-bar .wordmark{font-size:20px;font-weight:700;font-style:italic;letter-spacing:-.02em}
  .app-bar .ic{display:flex;gap:16px;color:#262626}
  .ig-head{display:flex;align-items:center;gap:10px;padding:9px 14px}
  .ig-ring{padding:2px;border-radius:50%;background:linear-gradient(45deg,#feda75,#fa7e1e,#d62976,#962fbf,#4f5bd5)}
  .ig-ava{width:30px;height:30px;border-radius:50%;background:#fff;border:2px solid #fff;color:#262626;display:grid;place-items:center;font-weight:700;font-size:12px;overflow:hidden}
  .ig-ava img{width:100%;height:100%;object-fit:cover;border-radius:50%}
  .ig-id{flex:1;line-height:1.15}
  .ig-id .ig-user{display:block}
  .ig-user{font-weight:600;font-size:13px;color:#262626}
  .ig-loc{display:block;font-size:11px;color:#737373}
  .ig-more{color:#262626;font-size:20px;line-height:1;font-weight:700}
  .ig-img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:#eee}
  .ig-noimg{display:grid;place-items:center;color:#999;aspect-ratio:1/1;font-size:13px}
  .ig-actions{display:flex;align-items:center;justify-content:space-between;padding:8px 13px 4px;color:#262626}
  .ig-actions .left{display:flex;gap:13px}
  .ig-likes{padding:2px 14px;font-weight:600;font-size:14px}
  .ig-cap{padding:2px 14px;font-size:14px;line-height:1.45}
  .ig-cap .ig-user{margin-right:5px}
  .ig-comments{padding:5px 14px 0;font-size:14px;color:#737373}
  .ig-time{padding:3px 14px 14px;font-size:10px;text-transform:uppercase;letter-spacing:.03em;color:#999}
  .tool{display:flex;flex-direction:column;align-items:center;gap:11px;width:100%;max-width:430px}
  .status-pill{font-size:11px;text-transform:uppercase;letter-spacing:.05em;font-weight:700;padding:4px 12px;border-radius:999px;background:#efefef}
  .actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
  .btn{padding:9px 14px;border-radius:10px;font-weight:600;font-size:13.5px;text-decoration:none;cursor:pointer;border:1px solid transparent}
  .btn.ok{background:#16a34a;color:#fff}
  .btn.no{background:#dc2626;color:#fff}
  .btn.ghost{background:#fff;color:#262626;border:1px solid #dbdbdb}
  .btn.solid{background:#0095f6;color:#fff}
  .flash{width:100%;max-width:430px;background:#eafff0;border:1px solid #16a34a;color:#13683a;padding:10px 14px;border-radius:10px;font-weight:600;text-align:center}
  h2{text-align:center}
/*]]>*/</style></head><body>${inner}</body></html>`;
}

// ───────────────────────────── router ─────────────────────────────
Deno.serve(async (req) => {
  const url = new URL(req.url);
  const p = url.searchParams;
  // ── trava de acesso: passa se tiver o header do proxy OU a chave de fallback ──
  const key = p.get("key") ?? "";
  const okHeader = PROXY_SECRET && req.headers.get("x-proxy-secret") === PROXY_SECRET;
  const okKey = ACCESS_KEY && key === ACCESS_KEY;
  const gated = Boolean(PROXY_SECRET || ACCESS_KEY);
  if (gated && !okHeader && !okKey) {
    return html(page(`<h2>🔒 acesso restrito</h2><p>esta função só responde através do proxy autorizado.</p>`), 403);
  }
  try {
    if (p.get("dl")) return await download(p.get("dl")!, p.get("id") ?? "");
    if (p.get("approve")) return await setStatus(p.get("approve")!, "aprovado", key);
    if (p.get("reject")) return await setStatus(p.get("reject")!, "descartado", key);
    if (p.get("id")) return await renderCard(p.get("id")!, key, p.get("flash") ?? "");
    return await generate(key); // GET sem parâmetro = gera um novo
  } catch (e) {
    return html(page(`<h2>⚠ Erro</h2><pre style="white-space:pre-wrap;max-width:600px">${esc(String((e as Error).message))}</pre><a class="btn solid" href="?">↻ Tentar de novo</a>`), 500);
  }
});
