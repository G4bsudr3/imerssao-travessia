# Material do aluno — Segurança em IA & Automação

Bem-vindo! Aqui está tudo pra você **estudar** e **replicar o lab** do workshop.

## Por onde começar
1. **lab-guia.pdf** — passo a passo pra construir a automação do zero (Supabase + Cloudflare), do jeito errado (aberto) → ao jeito certo (protegido). Comece por aqui.
2. **estudo.pdf** — handbook teórico: segurança em IA, prompt injection, LGPD, base legal, RLS, Supabase, Cloudflare + perguntas e respostas. Leia pra entender o "porquê".

## Os códigos (copie e cole)
- `edge-functions/post-generator-open/index.ts` — a versão **aberta** (a maneira errada, pra demonstrar o risco).
- `edge-functions/post-generator/index.ts` — a versão **travada** (a maneira certa, usada com o proxy).
- `edge-functions/post-direct/index.ts` — extra: versão que abre direto (SVG) protegida por chave na URL.
- `cloudflare-worker.js` — o proxy seguro na Cloudflare.
- `setup.sql` — cria a tabela `posts` e o bucket no Supabase.

## Você vai precisar (tudo tem plano grátis)
- Conta **Supabase** (banco + edge functions)
- Conta **OpenAI** com um pouco de crédito (gera texto e imagem)
- Conta **Firecrawl** (lê o perfil de inspiração)
- Conta **Cloudflare** (o proxy/Worker)

> ⚠️ Use **as suas próprias chaves de API**. Elas vão só nos *secrets* do servidor — nunca no código do front, nunca compartilhadas. Defina um limite de gasto na OpenAI pra dormir tranquilo.

Bons estudos — e vai lá e cria, com segurança! 🚀
